import{_ as e,o as s,c}from"./index-de6d9716.js";const t="/assets/index-9b226edb.png",n={},o={src:t};function r(_,a){return s(),c("img",o)}const d=e(n,[["render",r]]);export{d as default};
