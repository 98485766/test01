package com.example;

import com.example.mapper.EmpMapper;
import com.example.pojo.Emp;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class Test03ApplicationTests {
    @Autowired
    private EmpMapper empMapper ;
    @Test
    void contextLoads() {
    }

    @Test
    public void TestEmp(){
        /*List<Emp> list = empMapper.list();
        for (Emp emp : list) {
            System.out.println(emp);
        }*/

    }
}
