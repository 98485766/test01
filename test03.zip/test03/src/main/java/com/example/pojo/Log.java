package com.example.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Log {
    private Number total;//总记录数
    private Object[] rows;//数据列表
    private Number id;//id
    private Number operateEmpId;//操作人ID
    private String operateTime;//操作时间
    private String className;//类名
    private String methodName;//方法名
    private String methodParams;//方法请求参数
    private String returnValue;//返回值
    private String costTime;//执行耗时, 单位ms
    private String operateEmpName;//操作人姓名


}
