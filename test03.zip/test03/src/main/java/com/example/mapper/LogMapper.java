package com.example.mapper;

import com.example.pojo.Log;
import com.example.pojo.LogQueryParam;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface LogMapper {

    List<Log> list(LogQueryParam logqp);
}
