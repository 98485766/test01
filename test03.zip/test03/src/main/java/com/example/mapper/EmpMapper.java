package com.example.mapper;

import com.example.pojo.Emp;
import com.example.pojo.EmpQueryParam;
import org.apache.ibatis.annotations.MapKey;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface EmpMapper {

public List<Emp> list(EmpQueryParam param);

   void add(Emp emp);

  void delete(List<Integer> ids);

  Emp getById(Integer id);

  void updateById(Emp emp);
/* 统计各个职位的员工人数*/
  @MapKey("pos")
  List<Map<String,Object>> countEmpJobData();

  @MapKey("name")
  List<Map> countEmpGenderData();

  List<Emp> query();

  @Select("select * from emp where username = #{username} and password = #{password}")
  Emp select(Emp emp);
}
