package com.example.mapper;

import com.example.pojo.StuQueryParam;
import com.example.pojo.Student;
import org.apache.ibatis.annotations.MapKey;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface StuMapper {

    List<Student> list(StuQueryParam param);

    void delete( List<Integer> ids);

    void add(Student student);

    Student getById(Integer id);

    void update(Student student);

    void violation(Integer id, short score);

    @MapKey("name")
    List<Map> countStudentDegreeData();

}
