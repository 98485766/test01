package com.example.mapper;

import com.example.pojo.Clazz;
import com.example.pojo.ClazzQueryParam;
import org.apache.ibatis.annotations.MapKey;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface ClassMapper {

    List<Clazz> list(ClazzQueryParam clazz);

    void delete(Integer id);

    void add(Clazz clazz);

    Clazz getById(Integer id);

    void update(Clazz clazz);

    Integer getStuCount(Integer id);

    List<Clazz> listAll();

    @MapKey("cla")
    List<Map<String, Object>> countStudentCountData();
}
