package com.example.service;

import com.example.pojo.Clazz;
import com.example.pojo.ClazzQueryParam;
import com.example.pojo.PageBean;
import org.springframework.stereotype.Service;

import java.util.List;


public interface ClassService {
    PageBean list(ClazzQueryParam clazz);

    void delete(Integer id);

    void add(Clazz clazz);

    Clazz getById(Integer id);

    void update(Clazz clazz);

    List<Clazz> listAll();
}
