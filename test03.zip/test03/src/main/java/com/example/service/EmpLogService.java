package com.example.service;

import com.example.pojo.EmpLog;
import org.springframework.stereotype.Service;

import java.util.List;

public interface EmpLogService {
	//记录新增员工日志
    public void insertLog(EmpLog empLog);

}