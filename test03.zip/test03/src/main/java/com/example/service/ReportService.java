package com.example.service;

import com.example.pojo.JobOption;
import com.example.pojo.StuOption;

import java.util.List;
import java.util.Map;


public interface ReportService {
    /*统计各个职位的员工人数*/
    JobOption getEmpJobData();

    List<Map> getgetEmpGenderData();


    List<Map> getStudentDegreeData();

    StuOption getStudentCountData();
}
