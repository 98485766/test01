package com.example.service.impl;

import com.example.exception.ClassHasStudentsException;
import com.example.mapper.ClassMapper;
import com.example.pojo.Clazz;
import com.example.pojo.ClazzQueryParam;
import com.example.pojo.PageBean;
import com.example.service.ClassService;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ClassServiceimpl implements ClassService {
    @Autowired
    private ClassMapper classMapper;
    @Override
    public PageBean list(ClazzQueryParam clazz) {
        PageHelper.startPage(clazz.getPage(),clazz.getPageSize());
        List<Clazz> list = classMapper.list(clazz);
        Page<Clazz> cla = (Page<Clazz>) list;
        return new PageBean(cla.getTotal(),cla.getResult());
    }

    @Transactional(rollbackFor = Exception.class )
    @Override
    public void delete(Integer id) {
        if(classMapper.getStuCount(id)==0){
            classMapper.delete(id);
        }
        else {
            throw new ClassHasStudentsException();
        }
    }

    @Override
    public void add(Clazz clazz) {
        clazz.setCreateTime(LocalDateTime.now());
        clazz.setUpdateTime(LocalDateTime.now());
        classMapper.add(clazz);
    }

    @Override
    public Clazz getById(Integer id) {
        Clazz c = classMapper.getById(id);
        return c;
    }

    @Override
    public void update(Clazz clazz) {
        clazz.setUpdateTime(LocalDateTime.now());
        classMapper.update(clazz);
    }

    @Override
    public List<Clazz> listAll() {
        List<Clazz> c = classMapper.listAll();
        return c;
    }
}
