package com.example.service.impl;
import com.example.mapper.LogMapper;
import com.example.pojo.Log;
import com.example.pojo.LogQueryParam;
import com.example.pojo.PageBean;
import com.example.pojo.Student;
import com.example.service.LogService;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LogServiceimpl implements LogService {
    @Autowired
    private LogMapper  logMappper;

    @Override
    public PageBean list(LogQueryParam logqp) {
        PageHelper.startPage(logqp.getPage(), logqp.getPageSize());
        List<Log> stulist = logMappper.list(logqp);
        Page<Log> s = (Page<Log>) stulist;
        return new PageBean(s.getTotal(),s.getResult());
    }
}
