package com.example.service;

import com.example.pojo.Emp;
import com.example.pojo.EmpQueryParam;
import com.example.pojo.LoginInfo;
import com.example.pojo.PageBean;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.List;

@Service
public interface EmpService {

    PageBean list(EmpQueryParam param);

    void add(Emp emp) throws Exception;


    void delete(List<Integer> ids);

    Emp getById(Integer id);

    void update(Emp emp);


    List<Emp> query();

    LoginInfo login(Emp emp);
}
