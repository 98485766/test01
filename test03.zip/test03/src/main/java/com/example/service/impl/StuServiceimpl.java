package com.example.service.impl;

import com.example.mapper.StuMapper;
import com.example.pojo.Clazz;
import com.example.pojo.PageBean;
import com.example.pojo.StuQueryParam;
import com.example.pojo.Student;
import com.example.service.StuService;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class StuServiceimpl implements StuService {
    @Autowired
    private StuMapper stuMapper;

    @Override
    public PageBean list(StuQueryParam param) {
        PageHelper.startPage(param.getPage(),param.getPageSize());
        List<Student> stulist = stuMapper.list(param);
        Page<Student> s = (Page<Student>) stulist;
        return new PageBean(s.getTotal(),s.getResult());
    }

    @Override
    public void delete( List<Integer> ids) {
        stuMapper.delete(ids);
    }

    @Override
    public void add(Student student) {
        student.setCreateTime(LocalDateTime.now());
        student.setUpdateTime(LocalDateTime.now());
        stuMapper.add(student);
    }

    @Override
    public Student getById(Integer id) {
        Student s = stuMapper.getById(id);
        return s;
    }

    @Override
    public void update(Student student) {
        student.setUpdateTime(LocalDateTime.now());
        stuMapper.update(student);
    }

    @Override
    public void violation(Integer id, short score) {
        stuMapper.violation(id,score);
    }
}
