package com.example.service.impl;

import com.example.mapper.ClassMapper;
import com.example.mapper.EmpMapper;
import com.example.mapper.StuMapper;
import com.example.pojo.Clazz;
import com.example.pojo.JobOption;
import com.example.pojo.StuOption;
import com.example.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class ReportServiceimpl implements ReportService {
    @Autowired
    private EmpMapper empMapper;
    @Autowired
    private StuMapper stuMapper;
    @Autowired
    private ClassMapper classMapper;

    @Override
    public JobOption getEmpJobData() {
        List<Map<String, Object>> list = empMapper.countEmpJobData();
        List<Object> jobList = list.stream().map(dataMap -> dataMap.get("pos")).toList();
        List<Object> dataList = list.stream().map(dataMap -> dataMap.get("total")).toList();
        return new JobOption(jobList,dataList);
    }

    @Override
    public List<Map> getgetEmpGenderData() {
        return empMapper.countEmpGenderData();
    }

    @Override
    public List<Map>  getStudentDegreeData() {
        List<Map> list = stuMapper.countStudentDegreeData();
        return  list;
    }

    @Override
    public StuOption getStudentCountData() {
        List<Map<String, Object>> list = classMapper.countStudentCountData();
        List<Object> clazzList = list.stream().map(dataMap -> dataMap.get("cla")).toList();
        List<Object> dataList = list.stream().map(dataMap -> dataMap.get("data")).toList();
        return new StuOption(clazzList,dataList);
    }
}
