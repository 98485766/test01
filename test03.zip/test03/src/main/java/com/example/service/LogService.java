package com.example.service;

import com.example.pojo.LogQueryParam;
import com.example.pojo.PageBean;
import org.springframework.stereotype.Service;

@Service
public interface LogService {
    PageBean list(LogQueryParam logqp);
}
