package com.example.service;

import com.example.pojo.PageBean;
import com.example.pojo.StuQueryParam;
import com.example.pojo.Student;

import java.util.List;

public interface StuService {
    PageBean list(StuQueryParam param);

    void delete( List<Integer> ids);

    void add(Student student);

    Student getById(Integer id);

    void update(Student student);

    void violation(Integer id, short score);
}
