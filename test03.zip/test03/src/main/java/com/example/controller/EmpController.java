package com.example.controller;

import com.example.pojo.Emp;
import com.example.pojo.EmpQueryParam;
import com.example.pojo.PageBean;
import com.example.pojo.Result;
import com.example.service.EmpService;
import lombok.extern.apachecommons.CommonsLog;
import lombok.extern.java.Log;
import org.apache.ibatis.annotations.Delete;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

@CommonsLog
@RequestMapping("/emps")
@RestController
public class EmpController {
    @Autowired
    private EmpService empService;

    @GetMapping
    public Result list(EmpQueryParam param){

      /*  System.out.println("page==" +page);
        System.out.println("pageSize==" +pageSize);*/
        PageBean pageBean = empService.list(param);
        return Result.success(pageBean);
    }


    @PostMapping
    public Result save(@RequestBody Emp emp) throws Exception {
        empService.add(emp);
        return Result.success();
    }
    @GetMapping("/list")
    public Result query(){
        List<Emp> query = empService.query();
        return Result.success(query);
    }

    @DeleteMapping
    public Result delete(@RequestParam List<Integer> ids){
        log.info("批量删除部门: ids={} "+ids);
        empService.delete(ids);
        return Result.success();
    }

    @GetMapping("/{id}")
    public Result getById(@PathVariable Integer id){
        log.info("根据id查询员工的详细信息");
        Emp emp = empService.getById(id);
        return Result.success(emp);
    }

    @PutMapping
    public Result update(@RequestBody Emp emp){
        empService.update(emp);
        return Result.success();
    }
}
