package com.example.controller;

import com.example.pojo.PageBean;
import com.example.pojo.Result;
import com.example.pojo.StuQueryParam;
import com.example.pojo.Student;
import com.example.service.StuService;
import lombok.extern.apachecommons.CommonsLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CommonsLog
@RequestMapping("/students")
@RestController
public class StuController {
    @Autowired
    private StuService stuService;

    @GetMapping
    public Result list(StuQueryParam param){
        PageBean pageBean =  stuService.list(param);
        return Result.success(pageBean);
    }

    @DeleteMapping("/{ids}")
    public Result delete(@PathVariable List<Integer> ids){
        stuService.delete(ids);
        return Result.success();
    }

    @PostMapping
    public Result add(@RequestBody Student student){
        stuService.add(student);
        return Result.success();
    }

    @GetMapping("/{id}")
    public Result getById(@PathVariable Integer id){
        Student student = stuService.getById(id);
        return Result.success(student);
    }
    @PutMapping
    public Result update(@RequestBody Student student){
        stuService.update(student);
        return Result.success();
    }

    @PutMapping("/violation/{id}/{score}")
    public Result violation(@PathVariable Integer id,@PathVariable short score) {
        stuService.violation(id,score);
        return Result.success();
    }
}
