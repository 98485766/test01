package com.example.controller;

import com.example.pojo.Clazz;
import com.example.pojo.ClazzQueryParam;
import com.example.pojo.PageBean;
import com.example.pojo.Result;
import com.example.service.ClassService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("clazzs")
@RestController
public class ClassController {
    @Autowired
    private ClassService  classService;

    @GetMapping
    public Result list(ClazzQueryParam clazz){
        PageBean  pageBean = classService.list(clazz);
        return Result.success(pageBean);
    }

    @DeleteMapping("/{id}")
    public Result delete(@PathVariable Integer id){
        classService.delete(id);
        return Result.success();
    }

    @PostMapping
    public Result add(@RequestBody Clazz  clazz){
        classService.add(clazz);
        return Result.success();
    }

    @GetMapping("/{id}")
    public Result getById(@PathVariable Integer id){
        Clazz clazz = classService.getById(id);
        return Result.success(clazz);
    }

    @PutMapping
    public Result update(@RequestBody Clazz clazz){
        classService.update(clazz);
        return Result.success();
    }

    @GetMapping("/list")
    public Result listAll(){
        List<Clazz> clazzList = classService.listAll();
        return Result.success(clazzList);
    }
}
