package com.example.controller;

import com.example.pojo.LogQueryParam;
import com.example.pojo.PageBean;
import com.example.pojo.Result;
import com.example.service.LogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/log/page")
public class LogController {
    @Autowired
    private LogService  logService;

    @GetMapping
    public Result list(LogQueryParam logqp){
        PageBean pageBean = logService.list(logqp);
        return Result.success(pageBean);
    }
}
