package com.example.controller;

import com.example.pojo.Dept;
import com.example.pojo.Result;
import com.example.service.DeptService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.apachecommons.CommonsLog;
import org.apache.ibatis.annotations.Update;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CommonsLog
@RequestMapping("/depts")
@RestController
public class DeptController {
    @Autowired
    private DeptService deptService;

    @GetMapping
    public Result getDepts(){
        List<Dept> list = deptService.getDeptList();
        return Result.success(list);
    }

    @PostMapping
    public Result addDept(@RequestBody Dept dept){
        System.out.println("添加部门: " + dept);
        deptService.add(dept);
        return Result.success();
    }
    @DeleteMapping
    public Result delete(Integer id){
        System.out.println("根据ID删除部门: " + id);
        deptService.delete(id);
        return Result.success();
    }
    @GetMapping("/{id}")
    public Result getDeptById(@PathVariable Integer id){
        System.out.println("根据ID查询部门数据: " + id);
        Dept dept = deptService.getInfo(id);
        return Result.success(dept);
    }
    @PutMapping
    public Result UpDate(@RequestBody Dept dept){
        System.out.println("修改部门数据: " + dept);
        deptService.update(dept);
        return Result.success();
    }
}
