package com.example.controller;

import com.example.pojo.Emp;
import com.example.pojo.LoginInfo;
import com.example.pojo.Result;
import com.example.service.EmpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LoginController {
    @Autowired
    private EmpService  empService;

    @PostMapping("/login")
    public Result loginfo(@RequestBody Emp emp){
        LoginInfo  loginInfo = empService.login(emp);
        return Result.success(loginInfo);
    }
}
