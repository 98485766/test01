package com.example.exception;

public class ClassHasStudentsException extends RuntimeException {
}
